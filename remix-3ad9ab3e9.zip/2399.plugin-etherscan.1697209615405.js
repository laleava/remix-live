"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([[2399],{

/***/ 72399:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("import { deploy } from './web3-lib'\n\n(async () => {\n  try {\n    const result = await deploy('SampleERC20', [\"TestToken\", \"TST\", 18, 1000])\n    console.log(`address: ${result.address}`)\n  } catch (e) {\n    console.log(e.message)\n  }\n})()");

/***/ })

}]);
//# sourceMappingURL=2399.plugin-etherscan.1697209615405.js.map